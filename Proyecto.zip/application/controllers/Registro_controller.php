<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Registro_controller extends CI_Controller {

	public function index(){
		$this->load->view('Registro_view');
	}
}
